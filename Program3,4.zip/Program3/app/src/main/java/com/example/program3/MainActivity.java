package com.example.program3;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
public class MainActivity extends AppCompatActivity {
    FirstFragment firstFragment;
    SecondFragment secondFragment;
    int showingFragment=0;
    Button b1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1=findViewById(R.id.button);
        firstFragment=new FirstFragment();
        secondFragment=new SecondFragment();
        FragmentManager fragmentManager=getSupportFragmentManager();
        FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
        fragmentTransaction.add(R.id.frameLayout,firstFragment);
        fragmentTransaction.commit();
        showingFragment=1;
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FragmentManager fragmentManager=getSupportFragmentManager();
                FragmentTransaction fragmentTransaction=fragmentManager.beginTransaction();
                if(showingFragment==1)
                {
                    fragmentTransaction.replace(R.id.frameLayout,secondFragment);
                    showingFragment=2;
                }
                else
                {
                    fragmentTransaction.replace(R.id.frameLayout,firstFragment);
                    showingFragment=1;
                }
                fragmentTransaction.commit();
            }
        });
    }
}